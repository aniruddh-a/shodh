(function() {
    'use strict';

    angular
        .module('app.utils', [
          'app.colors'
          ]);
})();
