(function() {
    'use strict';

    angular
        .module('app.mailbox', []);
})();